<?php
session_start();
?>
<html>
<head>
<meta charset="utf-8">
</head>

<?php
if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="Yes"){
        echo "hello reviewer, welcome to the paper review page<br/>";
    }else{
        echo "illegal enter";
        echo "going back in 3 seconds";
        header("Refresh:3;url=index.php");
    }
}else{
        echo "illegal enter";
        echo "going back in 3 seconds";
        header("Refresh:3;url=index.php");
    }
?>

<form action="showreview.php" method="post">
paper review decision: 
<input type="radio" name="decision" value = "accept">accept 
<input type="radio" name="decision" value = "minor revision">minor revision 
<input type="radio" name="decision" value = "major revision">major revision 
<input type="radio" name="decision" value = "reject">reject </br>
paper review comment: <textarea name="comment" value="" rows="15" cols="45"> </textarea> </br>
<input type = "submit"></br> </br>
<a href='logout.php'> sign out</a>
</form>
</html>