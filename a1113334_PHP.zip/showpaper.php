<meta charset=utf8>

<?php
    $title=$_POST["title"];
    echo "paper title: ";
    echo $title."<br/>";
    $aName=$_POST["aName"];
    echo "author name: ";
    echo $aName."<br/>";
    $aEmail=$_POST["aEmail"];
    echo "author email: ";
    echo $aEmail."<br/>";
    $abstract=$_POST["abstract"];
    echo "paper abstract: <br/>";
    echo $abstract."<br/>";
?>

<a href='logout.php'> sign out</a>