<?php
session_start();
?>
<html>
<meta charset="utf-8">
<?php

if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="Yes"){
        echo "login success </br>";
        echo "welcome to the website, chairman<br/>";
        echo "<a href='logout.php'>sign out</a>";
    }else{
        echo "illegal";
        echo "refresh";
        header("Refresh:3;url=login.php");
    }
}else{
        echo "illegal";
        echo "refresh";
        header("Refresh:3;url=login.php");
    }
 
?>
</html>