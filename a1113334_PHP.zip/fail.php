<meta charset="utf-8">

<?php

echo "login failed <br/>";
echo "will return to login screen in 3 seconds";
header("Refresh:3;url=index.php");

?>