<meta charset="utf-8">

<?php include "include.inc";
?>

<form action="check.php" method="get">
role:<select name="role">
<option value="chair">chair
<option value="reviewer">reviewer
<option value="author">author  
</select> </br>
name:<input type = "text" name = "uId"><br/>
password:<input type = "password" name = "uPwd"><br/>

<input type = "submit">

</form>

