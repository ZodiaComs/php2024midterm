<meta charset=utf8>

<?php
    $decision=$_POST["decision"];
    echo "paper review decision: ";
    echo $decision."<br/>";
    $comment=$_POST["comment"];
    echo "paper review comment: <br/>";
    echo $comment."<br/>";
?>

<a href='logout.php'> sign out</a>