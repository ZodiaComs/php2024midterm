<?php
ob_start();
session_start();
?>

<meta charset="utf-8">
<?php
$sID1 = "chair";
$sPWD1 = "123";

$sID2 = "reviewer";
$sPWD2 = "234";

$sID3 = "author";
$sPWD3 = "345";

$role=$_GET["role"];
$uId=$_GET["uId"];
$uPwd=$_GET["uPwd"];

if($sID1==$uId && $sPWD1==$uPwd && $role == "chair")
{
    $_SESSION["check"]="Yes";
    header("Location:chair.php");
}

else if($sID2==$uId && $sPWD2==$uPwd && $role == "reviewer")
{
    $_SESSION["check"]="Yes";
    header("Location:reviewer.php");
}

else if($sID3==$uId && $sPWD3==$uPwd && $role == "author")
{
    $_SESSION["check"]="Yes";
    header("Location:author.php");
}

else{
    $_SESSION["check"]="No";
    header("Location:fail.php");
}
ob_flush();
?>