<?php
session_start();
?>
<html>
<meta charset="utf-8">
<form action="showpaper.php" method="post">
<?php
if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="Yes"){
        echo "hello author, welcome to the paper submission page<br/>";
    }else{
        echo "illegal enter";
        echo "going back in 3 seconds";
        header("Refresh:3;url=index.php");
    }
}else{
        echo "illegal enter";
        echo "going back in 3 seconds";
        header("Refresh:3;url=index.php");
    }
?>

paper title: </br>
<input type = "text" name = "title"><br/>
author name: <input type = "text" name = "aName"><br/>
author email: <input type = "email" name= "aEmail"><br/>
paper abstract: <textarea name="abstract" value="" rows="15" cols="45"> </textarea> </br>
<input type = "submit"></br> </br>
<a href='logout.php'> sign out</a>
</html>